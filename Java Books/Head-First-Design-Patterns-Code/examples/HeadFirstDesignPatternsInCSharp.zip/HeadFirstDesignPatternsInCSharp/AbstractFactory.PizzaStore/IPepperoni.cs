using System;

namespace HeadFirstDesignPatterns.AbstractFactory.PizzaStore
{
	/// <summary>
	/// Summary description for IPepperoni.
	/// </summary>
	public interface IPepperoni
	{
		string toString();
	}
}
